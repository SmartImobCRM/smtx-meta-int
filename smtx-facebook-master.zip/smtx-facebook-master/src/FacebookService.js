import { FacebookAuthProvider, getAuth, signInWithPopup } from 'firebase/auth';
import { app } from './FirebaseConfig';
import axios from 'axios';

const auth = getAuth(app);
const provider = new FacebookAuthProvider();
const appId = '217878241105194';
const appSecret = '37bfcb7142c2ee5d1adb28b3991c096b';

// Login no facebook 
export function login() {
    window.FB.login(function (response) {
        console.log(response);
        getLongDurationToken(response.authResponse.accessToken);
    }, { scope: 'pages_manage_ads,pages_read_engagement,pages_show_list,leads_retrieval' });
}

// Logout
export function logout() {
    window.FB.logout();
}

// Recupera o token de todas as páginas que o usuário permitiu acesso.
export function getMyPages(token) {
    return new Promise((resolve, reject) => {
        window.FB.api('/me/accounts', { 'access_token': token }, function (response) {
            console.log(response);
            resolve(response);
        });
    });
}

// Obtem todos os forms que da página
// pageId = Id da página
// accessToken = Token da página
export function getForms(pageId, accessToken) {
    return new Promise((resolve, reject) => {
        window.FB.api(`${pageId}/leadgen_forms`, { 'access_token': accessToken }, function (response) {
            resolve(response);
        });
    });
}

// Obtem todos os leads do form
// formId - Id do formulário
// accessToken - Token da página
export function getLeads(formId, accessToken) {
    return new Promise((resolve, reject) => {
        window.FB.api(`${formId}/leads`, { 'access_token': accessToken }, function (response) {
            resolve(response);
        });
    });
}

// Obtem token de longa duração do usuário
// token - Access Token do usuário
function getLongDurationToken(token) {
    return new Promise((resolve, reject) => {
        axios.get(
            "https://graph.facebook.com/v17.0/oauth/access_token",
            {
                params: {
                    grant_type: 'fb_exchange_token',
                    client_id: appId,
                    client_secret: appSecret,
                    fb_exchange_token: token,
                }
            },
        ).then(response => {
            resolve(response.data.access_token);
        });
    });

}

// Obtem token de longa duração da página
// userToken - Token de longa duração do usuário
// userId = Id do usuário no facebook
function getLongDurationPageToken(userToken, userId) {
    console.log(userToken);
    return new Promise((resolve, reject) => {
        axios.get(`https://graph.facebook.com/v17.0/${userId}/accounts`,
            {
                params: {
                    access_token: userToken,
                }
            },
        ).then(response => {
            resolve(response.data);
        });
    });
}


export function savePages(json) {
    // TO-DO
}
