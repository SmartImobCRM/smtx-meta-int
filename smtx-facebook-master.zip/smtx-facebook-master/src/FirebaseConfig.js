import { initializeApp } from "firebase/app";

const firebaseConfig = {
    apiKey: "AIzaSyCRY1RsUASByrwHaiXSzgLBa_KjcxA7HDk",
    authDomain: "smartimob-dev-test.firebaseapp.com",
    databaseURL: "https://smartimob-dev-test.firebaseio.com",
    projectId: "smartimob-dev-test",
    storageBucket: "smartimob-dev-test.appspot.com",
    messagingSenderId: "1030189605462",
    appId: "1:1030189605462:web:cb42f70fe0f892048051f7",
    measurementId: "G-KC82QWH0ZD"
};

const app = initializeApp(firebaseConfig);

export { app };