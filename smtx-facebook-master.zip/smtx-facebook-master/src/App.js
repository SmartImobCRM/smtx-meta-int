import logo from './logo.svg';
import './App.css';
import { auth, provider } from './FirebaseConfig';
import { signInWithPopup } from 'firebase/auth';

const facebookService = require('./FacebookService');



function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <button onClick={facebookService.login}>
          Login with Facebook
        </button>
        <button onClick={facebookService.logout}>
          Logout
        </button>
        <button onClick={facebookService.testes}>
          Get Data
        </button>
      </header>
    </div>
  );
}

export default App;
